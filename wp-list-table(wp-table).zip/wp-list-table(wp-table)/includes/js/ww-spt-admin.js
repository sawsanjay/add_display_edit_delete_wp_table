jQuery(document).ready(function ($) {
    $('#choose-image-button-ww').click(function (e) {
        e.preventDefault();

        // Open the WordPress media dialog box
        var frame = wp.media({
            title: 'Choose or Upload Image',
            button: {
                text: 'Use this image'
            },
            multiple: false  // Set to true if you want to allow multiple image selection
        });

        // When an image is selected in the media dialog box
        frame.on('select', function () {
            var attachment = frame.state().get('selection').first().toJSON();

            // Display the selected image with a fixed size
            $('#selected-image').attr('src', attachment.url).show();

            // Set the value of the hidden input to the selected image URL
            $('#selected-image-url').val(attachment.url);

            // Change button text to "Remove Image"
            $('#choose-image-button-ww').text('Remove Image');
        });

        // Open the media dialog box
        frame.open();
    });

    // Remove the selected image and revert to "Choose Image" state
    $('#image-container').on('click', '#choose-image-button-ww', function () {
        // Remove the selected image
        $('#selected-image').attr('src', '').hide();

        // Reset the value of the hidden input
        $('#selected-image-url').val('');

        // Change button text to "Choose Image"
        $('#choose-image-button-ww').text('Choose Image');
    });
});
